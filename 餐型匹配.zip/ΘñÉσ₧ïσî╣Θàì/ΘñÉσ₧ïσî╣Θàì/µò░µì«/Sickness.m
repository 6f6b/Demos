//
//  Sickness.m
//  餐型匹配
//
//  Created by 刘丰 on 2019/7/20.
//  Copyright © 2019 dev.liufeng@gmail.com. All rights reserved.
//

#import "Sickness.h"

@implementation Sickness
//- (instancetype)init{
//    if (self = [super init]) {
//        self.selected = YES;
//    }
//    return self;
//}
@end
