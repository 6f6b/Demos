//
//  CollectionHeaderView.m
//  餐型匹配
//
//  Created by 刘丰 on 2019/7/24.
//  Copyright © 2019 dev.liufeng@gmail.com. All rights reserved.
//

#import "CollectionHeaderView.h"

@implementation CollectionHeaderView

@end
