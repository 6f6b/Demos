//
//  AppDelegate.h
//  餐型匹配
//
//  Created by 刘丰 on 2019/7/19.
//  Copyright © 2019 dev.liufeng@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

